package se.lexicon.api.exception;

public class DataDuplicateException extends Exception {

    public DataDuplicateException(String message) {
        super(message);
    }

}
